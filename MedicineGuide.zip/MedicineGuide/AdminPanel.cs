﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminPanel : MetroFramework.Controls.MetroUserControl
    {
        Panel p;
        public AdminPanel(Panel p)
        {
            this.p = p;
            InitializeComponent();
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {

        }

        private void metroButton5_Click(object sender, EventArgs e)
        {

        }

        private void metroButton5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminOrders ao = new AdminOrders(p);
            p.Controls.Add(ao);
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminUserCheck ac = new AdminUserCheck(p);
            p.Controls.Add(ac);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminMedicine am = new AdminMedicine(p);
            p.Controls.Add(am);
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPharmacy al = new AdminPharmacy(p);
            p.Controls.Add(al);
        }

        private void metroButton6_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminAmbu au = new AdminAmbu(p);
            p.Controls.Add(au);
        }

        private void metroButton7_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDeliverySign asu = new AdminDeliverySign(p);
            p.Controls.Add(asu);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void metroButton8_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminForgotPassword ay = new AdminForgotPassword(p);
            p.Controls.Add(ay);
        }
    }
}
