﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class patientsPanelCart : MetroFramework.Controls.MetroUserControl
    {
        Panel p;
        string k;
        int g = 0;
        public patientsPanelCart(Panel p,string ab)
        {
            this.p = p;
            this.k = ab;
            InitializeComponent();
            this.materialLabel21.Text = ab;
        }

        private void materialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            patientsPanelcheck pt = new patientsPanelcheck(p,k,g);
            p.Controls.Add(pt);
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void materialLabel21_Click(object sender, EventArgs e)
        {

        }
    }
}
