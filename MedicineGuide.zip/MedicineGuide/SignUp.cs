﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class SignUp : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public SignUp(Panel p)
        {
            this.p = p;
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
           
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void materialRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            PharmacySignUp ph = new PharmacySignUp(p);
            p.Controls.Add(ph);

        }

        private void materialRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            signUp s = new signUp();

            string a = materialSingleLineTextField1.Text;
            string b = materialSingleLineTextField2.Text;
            string c = materialSingleLineTextField3.Text;
            string d = materialSingleLineTextField4.Text;
            string g = materialSingleLineTextField5.Text;
            string f = textBox6.Text;

            //var test = new MailAddress(b);
            //if(test != null) { MessageBox.Show("ye"); }

 
            if ((a == "Your text here") || (b == "Your text here") || (c == "Your text here") || (d == "Your text here") || (g == "Your text here") || (f == "Your text here"))
            {
                MessageBox.Show("Field can not be empty");
            }
            else
            {
                s.userType = "Patient";
                signUp vv = db.signUps.SingleOrDefault(x => x.userName == a);
                if (vv != null) { MessageBox.Show("Username not available,try another one"); }
                else
                {
                    s.userName = materialSingleLineTextField1.Text;
                    
                    String expression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

                    Regex regex = new Regex(expression);

                    String[] emails = b.Split(new Char[] { ';' });

                    foreach (String y in emails)
                    {

                        Match m = regex.Match(y);

                        if (!m.Success)
                        {
                            // Validation fails.
                            MessageBox.Show("Invalid Email Format");

                        }
                        else
                        {
                            s.email = materialSingleLineTextField2.Text;
                            if (materialSingleLineTextField3.Text == materialSingleLineTextField4.Text)
                            {
                                s.password = materialSingleLineTextField3.Text;

                                Regex nonNumericRegex = new Regex(@"\D");
                                if (nonNumericRegex.IsMatch(materialSingleLineTextField5.Text))
                                {
                                    MessageBox.Show("Enter number");
                                    //Contains non numeric characters.

                                }
                                else
                                {
                                    s.mobile = int.Parse(materialSingleLineTextField5.Text);
                                    s.address = textBox6.Text;
                                    db.signUps.InsertOnSubmit(s);
                                    db.SubmitChanges();

                                    MessageBox.Show("Your Account has been created!");
                                    this.Hide();
                                    HomePage hg = new HomePage(p);
                                    p.Controls.Add(hg);

                                }
                            
                            }
                            else { MessageBox.Show("please enter same password"); }


                        }
                    }
                    
                    
                }
                
            }
            
        }

        private void materialSingleLineTextField5_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField3_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
