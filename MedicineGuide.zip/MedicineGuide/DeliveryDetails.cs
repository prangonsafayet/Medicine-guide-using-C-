﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class DeliveryDetails : MetroFramework.Controls.MetroUserControl
    {
        Panel p;
        string k;
        public DeliveryDetails(Panel p,string ab)
        {
            this.p = p;
            this.k = ab;
            InitializeComponent();
            this.materialLabel2.Text = ab;
        }

        /*private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        } */

        private void metroButton1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeliveryPanel1 d = new DeliveryPanel1(p,k);
            p.Controls.Add(d);

        }
    }
}
