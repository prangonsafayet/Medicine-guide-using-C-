﻿namespace MedicineGuide
{
    partial class DeliveryPanel1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeliveryPanel1));
            this.label1 = new System.Windows.Forms.Label();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.materialLabel10 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel11 = new MaterialSkin.Controls.MaterialLabel();
            this.database1DataSet3 = new MedicineGuide.Database1DataSet3();
            this.medicineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medicineTableAdapter = new MedicineGuide.Database1DataSet3TableAdapters.medicineTableAdapter();
            this.database1DataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medicineBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet4 = new MedicineGuide.Database1DataSet4();
            this.dMedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dMedTableAdapter = new MedicineGuide.Database1DataSet4TableAdapters.dMedTableAdapter();
            this.dMedBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contactPersonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobileDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Region = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Medicine_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dMedBindingSource9 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet7 = new MedicineGuide.Database1DataSet7();
            this.medicineBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet5 = new MedicineGuide.Database1DataSet5();
            this.dMedBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedTableAdapter1 = new MedicineGuide.Database1DataSet5TableAdapters.dMedTableAdapter();
            this.database1DataSet = new MedicineGuide.Database1DataSet();
            this.database1DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pSignUpBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pSignUpTableAdapter = new MedicineGuide.Database1DataSetTableAdapters.pSignUpTableAdapter();
            this.dMedBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet6 = new MedicineGuide.Database1DataSet6();
            this.dMedBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.dMedTableAdapter2 = new MedicineGuide.Database1DataSet6TableAdapters.dMedTableAdapter();
            this.dMedTableAdapter3 = new MedicineGuide.Database1DataSet7TableAdapters.dMedTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pSignUpBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource8)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(230, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delivery Panel - New Order";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Transparent;
            this.metroButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton1.BackgroundImage")));
            this.metroButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.metroButton1.Location = new System.Drawing.Point(747, 19);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(108, 59);
            this.metroButton1.TabIndex = 22;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // materialLabel10
            // 
            this.materialLabel10.AutoSize = true;
            this.materialLabel10.BackColor = System.Drawing.Color.Transparent;
            this.materialLabel10.Depth = 0;
            this.materialLabel10.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel10.Location = new System.Drawing.Point(117, 70);
            this.materialLabel10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel10.Name = "materialLabel10";
            this.materialLabel10.Size = new System.Drawing.Size(116, 19);
            this.materialLabel10.TabIndex = 24;
            this.materialLabel10.Text = "materialLabel10";
            // 
            // materialLabel11
            // 
            this.materialLabel11.AutoSize = true;
            this.materialLabel11.BackColor = System.Drawing.Color.Transparent;
            this.materialLabel11.Depth = 0;
            this.materialLabel11.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel11.Location = new System.Drawing.Point(29, 70);
            this.materialLabel11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel11.Name = "materialLabel11";
            this.materialLabel11.Size = new System.Drawing.Size(81, 19);
            this.materialLabel11.TabIndex = 23;
            this.materialLabel11.Text = "Username:";
            // 
            // database1DataSet3
            // 
            this.database1DataSet3.DataSetName = "Database1DataSet3";
            this.database1DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicineBindingSource
            // 
            this.medicineBindingSource.DataMember = "medicine";
            this.medicineBindingSource.DataSource = this.database1DataSet3;
            // 
            // medicineTableAdapter
            // 
            this.medicineTableAdapter.ClearBeforeFill = true;
            // 
            // database1DataSet3BindingSource
            // 
            this.database1DataSet3BindingSource.DataSource = this.database1DataSet3;
            this.database1DataSet3BindingSource.Position = 0;
            // 
            // medicineBindingSource1
            // 
            this.medicineBindingSource1.DataMember = "medicine";
            this.medicineBindingSource1.DataSource = this.database1DataSet3;
            // 
            // database1DataSet4
            // 
            this.database1DataSet4.DataSetName = "Database1DataSet4";
            this.database1DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dMedBindingSource
            // 
            this.dMedBindingSource.DataMember = "dMed";
            this.dMedBindingSource.DataSource = this.database1DataSet4;
            // 
            // dMedTableAdapter
            // 
            this.dMedTableAdapter.ClearBeforeFill = true;
            // 
            // dMedBindingSource1
            // 
            this.dMedBindingSource1.DataMember = "dMed";
            this.dMedBindingSource1.DataSource = this.database1DataSet4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.contactPersonDataGridViewTextBoxColumn,
            this.mobileDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.Region,
            this.Medicine_Name,
            this.Quantity,
            this.Price,
            this.Column1});
            this.dataGridView1.DataSource = this.dMedBindingSource9;
            this.dataGridView1.Location = new System.Drawing.Point(33, 105);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(844, 294);
            this.dataGridView1.TabIndex = 25;
            // 
            // contactPersonDataGridViewTextBoxColumn
            // 
            this.contactPersonDataGridViewTextBoxColumn.DataPropertyName = "Contact_Person";
            this.contactPersonDataGridViewTextBoxColumn.HeaderText = "Contact_Person";
            this.contactPersonDataGridViewTextBoxColumn.Name = "contactPersonDataGridViewTextBoxColumn";
            // 
            // mobileDataGridViewTextBoxColumn
            // 
            this.mobileDataGridViewTextBoxColumn.DataPropertyName = "Mobile";
            this.mobileDataGridViewTextBoxColumn.HeaderText = "Mobile";
            this.mobileDataGridViewTextBoxColumn.Name = "mobileDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // Region
            // 
            this.Region.DataPropertyName = "Region";
            this.Region.HeaderText = "Region";
            this.Region.Name = "Region";
            // 
            // Medicine_Name
            // 
            this.Medicine_Name.DataPropertyName = "Medicine_Name";
            this.Medicine_Name.HeaderText = "Medicine_Name";
            this.Medicine_Name.Name = "Medicine_Name";
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Mark Delivered";
            this.Column1.Name = "Column1";
            // 
            // dMedBindingSource9
            // 
            this.dMedBindingSource9.DataMember = "dMed";
            this.dMedBindingSource9.DataSource = this.database1DataSet7;
            // 
            // database1DataSet7
            // 
            this.database1DataSet7.DataSetName = "Database1DataSet7";
            this.database1DataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicineBindingSource2
            // 
            this.medicineBindingSource2.DataMember = "medicine";
            this.medicineBindingSource2.DataSource = this.database1DataSet3;
            // 
            // database1DataSet5
            // 
            this.database1DataSet5.DataSetName = "Database1DataSet5";
            this.database1DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dMedBindingSource2
            // 
            this.dMedBindingSource2.DataMember = "dMed";
            this.dMedBindingSource2.DataSource = this.database1DataSet5;
            // 
            // dMedTableAdapter1
            // 
            this.dMedTableAdapter1.ClearBeforeFill = true;
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // database1DataSetBindingSource
            // 
            this.database1DataSetBindingSource.DataSource = this.database1DataSet;
            this.database1DataSetBindingSource.Position = 0;
            // 
            // pSignUpBindingSource
            // 
            this.pSignUpBindingSource.DataMember = "pSignUp";
            this.pSignUpBindingSource.DataSource = this.database1DataSet;
            // 
            // pSignUpTableAdapter
            // 
            this.pSignUpTableAdapter.ClearBeforeFill = true;
            // 
            // dMedBindingSource3
            // 
            this.dMedBindingSource3.DataMember = "dMed";
            this.dMedBindingSource3.DataSource = this.database1DataSet4;
            // 
            // dMedBindingSource4
            // 
            this.dMedBindingSource4.DataMember = "dMed";
            this.dMedBindingSource4.DataSource = this.database1DataSet5;
            // 
            // dMedBindingSource5
            // 
            this.dMedBindingSource5.DataMember = "dMed";
            this.dMedBindingSource5.DataSource = this.database1DataSet5;
            // 
            // dMedBindingSource6
            // 
            this.dMedBindingSource6.DataMember = "dMed";
            this.dMedBindingSource6.DataSource = this.database1DataSet4;
            // 
            // dMedBindingSource7
            // 
            this.dMedBindingSource7.DataMember = "dMed";
            this.dMedBindingSource7.DataSource = this.database1DataSet5;
            // 
            // database1DataSet6
            // 
            this.database1DataSet6.DataSetName = "Database1DataSet6";
            this.database1DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dMedBindingSource8
            // 
            this.dMedBindingSource8.DataMember = "dMed";
            this.dMedBindingSource8.DataSource = this.database1DataSet6;
            // 
            // dMedTableAdapter2
            // 
            this.dMedTableAdapter2.ClearBeforeFill = true;
            // 
            // dMedTableAdapter3
            // 
            this.dMedTableAdapter3.ClearBeforeFill = true;
            // 
            // DeliveryPanel1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.materialLabel10);
            this.Controls.Add(this.materialLabel11);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.label1);
            this.Name = "DeliveryPanel1";
            this.Size = new System.Drawing.Size(900, 440);
            this.Load += new System.EventHandler(this.DeliveryPanel1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicineBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pSignUpBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMedBindingSource8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MaterialSkin.Controls.MaterialLabel materialLabel10;
        private MaterialSkin.Controls.MaterialLabel materialLabel11;
        private Database1DataSet3 database1DataSet3;
        private System.Windows.Forms.BindingSource medicineBindingSource;
        private Database1DataSet3TableAdapters.medicineTableAdapter medicineTableAdapter;
        private System.Windows.Forms.BindingSource dMedBindingSource;
        private Database1DataSet4 database1DataSet4;
        private System.Windows.Forms.BindingSource database1DataSet3BindingSource;
        private System.Windows.Forms.BindingSource medicineBindingSource1;
        private Database1DataSet4TableAdapters.dMedTableAdapter dMedTableAdapter;
        private System.Windows.Forms.BindingSource dMedBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource dMedBindingSource2;
        private Database1DataSet5 database1DataSet5;
        private Database1DataSet5TableAdapters.dMedTableAdapter dMedTableAdapter1;
        private System.Windows.Forms.BindingSource pSignUpBindingSource;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource database1DataSetBindingSource;
        private Database1DataSetTableAdapters.pSignUpTableAdapter pSignUpTableAdapter;
        private System.Windows.Forms.BindingSource medicineBindingSource2;
        private System.Windows.Forms.BindingSource dMedBindingSource7;
        private System.Windows.Forms.BindingSource dMedBindingSource3;
        private System.Windows.Forms.BindingSource dMedBindingSource4;
        private System.Windows.Forms.BindingSource dMedBindingSource5;
        private System.Windows.Forms.BindingSource dMedBindingSource6;
        private System.Windows.Forms.BindingSource dMedBindingSource9;
        private Database1DataSet7 database1DataSet7;
        private Database1DataSet6 database1DataSet6;
        private System.Windows.Forms.BindingSource dMedBindingSource8;
        private Database1DataSet6TableAdapters.dMedTableAdapter dMedTableAdapter2;
        private Database1DataSet7TableAdapters.dMedTableAdapter dMedTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactPersonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobileDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Region;
        private System.Windows.Forms.DataGridViewTextBoxColumn Medicine_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
    }
}