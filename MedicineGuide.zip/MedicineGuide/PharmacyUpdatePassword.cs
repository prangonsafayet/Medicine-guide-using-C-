﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class PharmacyUpdatePassword : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        string pas;
        public PharmacyUpdatePassword(Panel p, string a)
        {
            this.pas = a;
            this.p = p;
            InitializeComponent();
        }

        private void PharmacyUpdatePassword_Load(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            string st = materialSingleLineTextField1.Text;

            if (st == "new password")
            {

                MessageBox.Show("enter a password!");
            }
            else
            {

                if (materialSingleLineTextField1.Text == materialSingleLineTextField2.Text)
                {
                    pSignUp s = db.pSignUps.SingleOrDefault(x => x.userName == pas);
                    s.password = materialSingleLineTextField1.Text;
                    db.SubmitChanges();
                    signUp sa = db.signUps.SingleOrDefault(x => x.userName == pas);
                    sa.password = materialSingleLineTextField1.Text;
                    db.SubmitChanges();
                    MessageBox.Show("password updated!");

                    this.Hide();
                    PharmacyPanel1 pj = new PharmacyPanel1(p, pas);
                    p.Controls.Add(pj);

                }
                else { MessageBox.Show("please enter same password"); }


            }
            
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }
    }
}
