﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class findAmbulance : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        string k;
        public findAmbulance(Panel p,string ab)
        {
            this.p = p;
            this.k = ab;
            InitializeComponent();
            this.materialLabel1.Text = ab;
            var sq = from a in db.GetTable<ambulance>()
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void PatientsPanel1_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            patientsPanelCart pc = new patientsPanelCart(p,k);
            p.Controls.Add(pc);
        }

        private void metroButton3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            PatientsHome uy = new PatientsHome(p,k);
            p.Controls.Add(uy);
        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string s = materialSingleLineTextField1.Text;
            if (s != null)
            {
                var sq = from a in db.GetTable<ambulance>()
                         where a.hName == s
                         select a;
                dataGridView1.DataSource = sq;
            }
            else { MessageBox.Show("Data not found!"); }
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            string s = checkedListBox1.Text;
            //pSignUp pp = new pSignUp();
            //pSignUp pp = db.pSignUps.SingleOrDefault(x => x.region == s);

            var sq = from a in db.GetTable<ambulance>()
                     where a.region == s
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
