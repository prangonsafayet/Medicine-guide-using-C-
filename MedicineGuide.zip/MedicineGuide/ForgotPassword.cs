﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class ForgotPassword : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public ForgotPassword(Panel p)
        {
            this.p = p;
            InitializeComponent();
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            fP sf = new fP();
            sf.userName = metroTextBox2.Text;
            string b = metroTextBox1.Text; ;

            String expression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

            Regex regex = new Regex(expression);

            String[] emails = b.Split(new Char[] { ';' });

            foreach (String y in emails)
            {

                Match m = regex.Match(y);

                if (!m.Success)
                {
                    // Validation fails.
                    MessageBox.Show("Invalid Email Format");

                }
                else
                {
                    sf.email = metroTextBox1.Text;
                    db.fPs.InsertOnSubmit(sf);
                    db.SubmitChanges();
                    MessageBox.Show("You will receive an email with your new password");

                    this.Hide();
                    HomePage hh = new HomePage(p);
                    p.Controls.Add(hh);
                }

            }
        }
    }
}
