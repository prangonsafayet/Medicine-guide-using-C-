﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{

    public partial class HomePage : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
       
        public HomePage(Panel p)
        {
            this.p = p;

           InitializeComponent();
        } 

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void htmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroLink1_Click(object sender, EventArgs e)
        {
            this.Hide();
            ForgotPassword fg = new ForgotPassword(p);
            p.Controls.Add(fg);
            
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUp su = new SignUp(p);
            p.Controls.Add(su);

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string s = metroTextBox1.Text;
            string s2 = metroTextBox2.Text;
            var str = from a2 in db.signUps
                      where a2.userName == s && a2.password == s2

                      select a2;
            signUp pa = str.First();
            s2 = pa.password.ToString();
            string s3 = pa.userType.ToString();

           

            if((s.Length==0) || (s2.Length==0))
            {
                MessageBox.Show("Please enter a valid input");
            }
            else
            {
                if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Admin"))
                {

                    this.Hide();
                    AdminPanel su = new AdminPanel(p);
                    p.Controls.Add(su);

                }

                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Patient"))
                {

                    this.Hide();

                    PatientsHome ph = new PatientsHome(p, metroTextBox1.Text);

                    p.Controls.Add(ph);
                }

                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Delivery"))
                {

                    this.Hide();
                    DeliveryPanel1 pp = new DeliveryPanel1(p, metroTextBox1.Text);
                    p.Controls.Add(pp);
                }
                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Pharmacy"))
                {

                    this.Hide();
                    PharmacyPanel1 pp = new PharmacyPanel1(p, metroTextBox1.Text);
                    p.Controls.Add(pp);

                }
                else
                {

                    MessageBox.Show("Invalid input");
                }
            } 
           /*if (metroTextBox1.Text != "username" && metroTextBox2.Text != "pass")
            {
                if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Admin"))
                {

                    this.Hide();
                    AdminPanel su = new AdminPanel(p);
                    p.Controls.Add(su);

                }

                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Patient"))
                {

                    this.Hide();

                    PatientsHome ph = new PatientsHome(p, metroTextBox1.Text);

                    p.Controls.Add(ph);
                }

                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Delivery"))
                {

                    this.Hide();
                    DeliveryPanel1 pp = new DeliveryPanel1(p, metroTextBox1.Text);
                    p.Controls.Add(pp);
                }
                else if (s.Equals(metroTextBox1.Text) && s2.Equals(metroTextBox2.Text) && s3.Equals("Pharmacy"))
                {

                    this.Hide();
                    PharmacyPanel1 pp = new PharmacyPanel1(p, metroTextBox1.Text);
                    p.Controls.Add(pp);

                }
                else
                {

                    MessageBox.Show("Invalid input");
                }
            }

            else
            {
                MessageBox.Show("Please enter a valid input");
            } */

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
                    }
    } 
}
