﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class PharmacyPanel1 : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        string un;
        public PharmacyPanel1(Panel p, string b)
        {
            this.un = b;
            this.p = p;

            InitializeComponent();
            pSignUp sp = db.pSignUps.SingleOrDefault(x => x.userName == un);
            this.materialLabel11.Text = sp.userName;
            this.materialLabel6.Text = sp.phName;
            this.materialLabel8.Text = sp.email;
            this.materialLabel7.Text = sp.mobile.ToString();
            this.materialLabel9.Text = sp.address;
            this.materialLabel10.Text = sp.region;
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            PharmacyUpdatePassword pn = new PharmacyUpdatePassword(p, materialLabel11.Text);
            p.Controls.Add(pn);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel6_Click(object sender, EventArgs e)
        {

        }
    }
}
