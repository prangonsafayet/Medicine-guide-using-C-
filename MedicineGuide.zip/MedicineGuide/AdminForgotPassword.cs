﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminForgotPassword : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public AdminForgotPassword(Panel p)
        {
            this.p = p;
            InitializeComponent();

            var sq = from a in db.GetTable<fP>()
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ay = new AdminPanel(p);
            p.Controls.Add(ay);
        }

        private void metroButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }
    }
}
