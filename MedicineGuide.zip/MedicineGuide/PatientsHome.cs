﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class PatientsHome : MetroFramework.Controls.MetroUserControl
    {
        Panel p;
        string k;
        public PatientsHome(Panel p,string ab)
        {
            this.p = p;
            this.k = ab;
            InitializeComponent();
            this.materialLabel2.Text = ab;
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            HomePage i = new HomePage(p);
            p.Controls.Add(i);
        }

        private void materialRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            PatientsPanel1 pg = new PatientsPanel1(p,k);
            p.Controls.Add(pg);
        }

       
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void materialRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            findPharmacy fp = new findPharmacy(p,k);
            p.Controls.Add(fp);
        }

        private void materialRadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            findAmbulance fa = new findAmbulance(p,k);
            p.Controls.Add(fa);
        }

        private void PatientsHome_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }
    }
}
