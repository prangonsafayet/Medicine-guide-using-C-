﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class patientsPanelcheck : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        string k;
        int g;
        public patientsPanelcheck(Panel p,string ab,int g)
        {
            this.p = p;
            this.k = ab;
            this.g = g;
            InitializeComponent();
            this.materialLabel2.Text = ab;
            this.materialLabel8.Text = g.ToString();

        }

        private void patientsPanelcheck_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            //dMed d = db.dMeds.SingleOrDefault(x => x.Contact_Person == k);
            dMed d = new dMed();

            var sq = from a in db.GetTable<dMed>()
                     where a.Contact_Person == k
                     select a;

            foreach(var val in sq)
            {
                d.Contact_Person = materialSingleLineTextField1.Text;
                Regex nonNumericRegex = new Regex(@"\D");
                if (nonNumericRegex.IsMatch(materialSingleLineTextField2.Text))
                {
                    MessageBox.Show("Enter number");
                    //Contains non numeric characters.

                }
                else
                {
                    d.Mobile = int.Parse(materialSingleLineTextField2.Text);
                    d.Address = textBox1.Text;
                    d.Region = checkedListBox2.Text;

                    db.SubmitChanges();
                    MessageBox.Show("Data updated!");
                    MessageBox.Show("Your order is being processed");
                    this.Hide();
                    PatientsHome nt = new PatientsHome(p, k);
                    p.Controls.Add(nt);
                }
            }
            


        }

        private void materialLabel2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void materialLabel8_Click(object sender, EventArgs e)
        {

        }
    }
}
