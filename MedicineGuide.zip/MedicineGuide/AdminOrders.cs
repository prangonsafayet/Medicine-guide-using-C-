﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminOrders : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public AdminOrders(Panel p)
        {
            this.p = p;
            InitializeComponent();
            var sq = from a in db.GetTable<dMed>()
                     select a;

            dataGridView1.DataSource = sq;
        }

        private void DeliveryPanel1_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroCheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void metroLink1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 dd = new Form2(p);
            p.Controls.Add(dd);

        }

        private void metroLink2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 d2 = new Form2(p);
            p.Controls.Add(d2);
        }

        private void metroLink3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 d3 = new Form2(p);
            p.Controls.Add(d3);
        }

        private void metroLink4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 d4 = new Form2(p);
            p.Controls.Add(d4);
        }

        private void metroLink5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 d5 = new Form2(p);
            p.Controls.Add(d5);
        }

        private void metroLink6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 d6 = new Form2(p);
            p.Controls.Add(d6);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
