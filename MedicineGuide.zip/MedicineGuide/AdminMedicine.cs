﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminMedicine : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public AdminMedicine(Panel p)
        {
            this.p = p;
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
           
        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void materialRadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            PharmacySignUp ph = new PharmacySignUp(p);
            p.Controls.Add(ph);

        }

        private void materialRadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField5_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField3_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void materialFlatButton2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminMedSearch pp1 = new AdminMedSearch(p);
            p.Controls.Add(pp1);
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void materialFlatButton1_Click_1(object sender, EventArgs e)
        {
            medicine ps = new medicine();
            

            string a = materialSingleLineTextField1.Text;
            string b = materialSingleLineTextField2.Text;
            string c = materialSingleLineTextField3.Text;
            string d = materialSingleLineTextField4.Text;
            string g = materialSingleLineTextField5.Text;
            string h = materialSingleLineTextField6.Text;
            

            if ((a == "Your text here") || (b == "Your text here") || (c == "Your text here") || (d == "Your text here") || (g == "Your text here") || (h == "Your text here"))
            {
                MessageBox.Show("Field can not be empty");
            }
            else
            {
                medicine vv = db.medicines.SingleOrDefault(x => x.mId == h);
                if (vv != null) { MessageBox.Show("Id not available,try another one"); }
                else
                {
                    ps.mId = materialSingleLineTextField6.Text;
                    ps.mName = materialSingleLineTextField1.Text;
                    ps.mSName = materialSingleLineTextField2.Text;
                    ps.disease = materialSingleLineTextField3.Text;
                    ps.price = int.Parse(materialSingleLineTextField5.Text);
                    ps.quantity = int.Parse(materialSingleLineTextField4.Text);

                    db.medicines.InsertOnSubmit(ps);
                    db.SubmitChanges();

                    MessageBox.Show("Medicine added successfully!");
                    this.Hide();
                    AdminPanel ay1 = new AdminPanel(p);
                    p.Controls.Add(ay1);
                }
                


            }

          
        }
    }
}
