﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminPharmacy : MetroFramework.Controls.MetroUserControl
    {
       
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public AdminPharmacy(Panel p)
        {
            this.p = p;
            InitializeComponent();
            var sq = from a in db.GetTable<pSignUp>()
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void PatientsPanel1_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void metroButton3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void metroButton3_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string s = materialSingleLineTextField1.Text;
            if (s != null)
            {
                var sq = from a in db.GetTable<pSignUp>()
                         where a.phName == s
                         select a;
                dataGridView1.DataSource = sq;
            }
            else { MessageBox.Show("Data not found!"); }

            /* pSignUp pp = db.pSignUps.SingleOrDefault(x => x.phName == s);
             if (s != null)
             {
                 materialLabel7.Text = pp.phName;
                 materialLabel8.Text = pp.mobile.ToString();
                 materialLabel9.Text = pp.address;
             }


             else { MessageBox.Show("Data not found!"); } */
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            string s = checkedListBox1.Text;
            //pSignUp pp = new pSignUp();
            //pSignUp pp = db.pSignUps.SingleOrDefault(x => x.region == s);

            var sq = from a in db.GetTable<pSignUp>()
                     where a.region == s
                     select a;
            dataGridView1.DataSource = sq;
            /*List<pSignUp> list = new List<pSignUp>();
            string s = checkedListBox1.Text;
            //pSignUp pp = db.pSignUps.SingleOrDefault(x => x.region == s);
            pSignUp pp = new pSignUp();
            //if (s != null)
            //{


            var query = from ps
                        in list
                        where pp.region == s
                        select ps;
            dataGridView1.DataSource = query.ToList(); */

            /* materialLabel16.Text = pp.phName;
             materialLabel15.Text = pp.mobile.ToString();
             materialLabel14.Text = pp.address; */
            // }


            // else { MessageBox.Show("Data not found!"); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
