﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using System.Text.RegularExpressions;

namespace MedicineGuide
{
    public partial class PharmacySignUp : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public PharmacySignUp(Panel p)
        {
            this.p = p;
            InitializeComponent();
        }

        private void PharmacySignUp_Load(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            signUp s = new signUp();
            pSignUp ps = new pSignUp();

            string a = materialSingleLineTextField1.Text;
            string b = materialSingleLineTextField2.Text;
            string c = materialSingleLineTextField3.Text;
            string d = materialSingleLineTextField4.Text;
            string g = materialSingleLineTextField5.Text;
            string h = materialSingleLineTextField6.Text;
            string f = textBox1.Text;

            if ((a == "Your text here") || (b == "Your text here") || (c == "Your text here") || (d == "Your text here") || (g == "Your text here") || (f == "Your text here") || (h == "Your text here"))
            {
                MessageBox.Show("Field can not be empty");
            }
            else
            {

                s.userType = "Pharmacy";
                signUp vv = db.signUps.SingleOrDefault(x => x.userName == a);
                if (vv != null) { MessageBox.Show("Username not available,try another one"); }
                else
                {
                    ps.userName = materialSingleLineTextField1.Text;
                    ps.phName = materialSingleLineTextField6.Text;
                    s.userName = materialSingleLineTextField1.Text;

                    String expression = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";

                    Regex regex = new Regex(expression);

                    String[] emails = b.Split(new Char[] { ';' });

                    foreach (String y in emails)
                    {

                        Match m = regex.Match(y);

                        if (!m.Success)
                        {
                            // Validation fails.
                            MessageBox.Show("Invalid Email Format");

                        }
                        else
                        {
                            ps.email = materialSingleLineTextField2.Text;
                            s.email = materialSingleLineTextField2.Text;
                            if (materialSingleLineTextField3.Text == materialSingleLineTextField4.Text)
                            {
                                ps.password = materialSingleLineTextField3.Text;

                                Regex nonNumericRegex = new Regex(@"\D");
                                if (nonNumericRegex.IsMatch(materialSingleLineTextField5.Text))
                                {
                                    MessageBox.Show("Enter number");
                                    //Contains non numeric characters.

                                }
                                else
                                {
                                    ps.mobile = int.Parse(materialSingleLineTextField5.Text);
                                    ps.address = textBox1.Text;
                                    ps.region = checkedListBox1.Text;
                                    db.pSignUps.InsertOnSubmit(ps);
                                    db.SubmitChanges();
                                    s.password = materialSingleLineTextField3.Text;
                                    s.mobile = int.Parse(materialSingleLineTextField5.Text);
                                    s.address = textBox1.Text;
                                    db.signUps.InsertOnSubmit(s);
                                    db.SubmitChanges();

                                    MessageBox.Show("Your Account has been created!");

                                    this.Hide();
                                    HomePage hg = new HomePage(p);
                                    p.Controls.Add(hg);
                                }
                                

                            }
                            else { MessageBox.Show("please enter same password"); }
                        }
                    }   
                }
                
            }
            
        }

        private void materialSingleLineTextField4_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
