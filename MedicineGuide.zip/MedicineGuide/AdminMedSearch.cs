﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class AdminMedSearch : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        public AdminMedSearch(Panel p)
        {
            this.p = p;
            InitializeComponent();
            var sq = from a in db.GetTable<medicine>()
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void PatientsPanel1_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void metroButton3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AdminPanel ap = new AdminPanel(p);
            p.Controls.Add(ap);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string s = materialSingleLineTextField1.Text;
            var sq = from a in db.GetTable<medicine>()
                     where a.mName == s
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            string s = checkedListBox1.Text;
            string s1 = checkedListBox2.Text;
            var sq = from a in db.GetTable<medicine>()
                     where a.mName.StartsWith(s1)
                     where a.disease == s
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {
            string s1 = materialSingleLineTextField1.Text;
            var sq = from a in db.GetTable<medicine>()
                     where a.mName.StartsWith(s1)
                     select a;
            dataGridView1.DataSource = sq;
        }
    }
}
