﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicineGuide
{
    public partial class PatientsPanel1 : MetroFramework.Controls.MetroUserControl
    {
        DataClasses1DataContext db = new DataClasses1DataContext(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=G:\semester8\C#\project\MedicineGuide-updated\MedicineGuide\MedicineGuide\Database1.mdf;Integrated Security=True");
        Panel p;
        string k;
        int u;
        int g = 0;
        public PatientsPanel1(Panel p,string ab)
        {
            this.p = p;
            this.k = ab;
            InitializeComponent();
            this.materialLabel1.Text = ab;
            
        }

        private void PatientsPanel1_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage hh = new HomePage(p);
            p.Controls.Add(hh);
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your order is being processed");

            this.Hide();
            PatientsHome nt = new PatientsHome(p, k);
            p.Controls.Add(nt);
        }

        private void materialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string s = materialSingleLineTextField1.Text;
            var sq = from a in db.GetTable<medicine>()
                     where a.mName == s
                     select a;
            dataGridView1.DataSource = sq;
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            PatientsHome uy = new PatientsHome(p, k);
            p.Controls.Add(uy);
        }

        private void metroButton5_Click(object sender, EventArgs e)
        {
            
            string s = checkedListBox1.Text;
            string s1 = checkedListBox2.Text;
            var sq = from a in db.GetTable<medicine>()
                     where a.mName.StartsWith(s1)
                     where a.disease == s
                     select a;
            dataGridView1.DataSource = sq;


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("hfdufh!");

            int j=0;
            //for (int j = 0; j <= e.RowIndex; j++)
            
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {

                    
                    
                    dMed dd = new dMed();

                    var h = (from a in db.GetTable<dMed>()
                             select a.mId).Max();

                    u = int.Parse(h) + 1;
                    //MessageBox.Show(h);
                    dd.mId = u.ToString();

                    //if (u >= 9) { u++; }

                    dd.Contact_Person = k;
                    dd.Medicine_Name = dataGridView1.Rows[j].Cells[0].Value.ToString();
                    signUp ss = db.signUps.SingleOrDefault(x => x.userName == dd.Contact_Person);
                    dd.Address = ss.address;
                    dd.Region = checkedListBox3.Text; ;

                    medicine m = db.medicines.SingleOrDefault(x => x.mName == dd.Medicine_Name);

                    dd.Mobile = ss.mobile;
                    dd.Quantity = int.Parse(dataGridView1.Rows[j].Cells[5].Value.ToString());
                    dd.Price = m.price * dd.Quantity;

                    g = g + dd.Price;

                    db.dMeds.InsertOnSubmit(dd);
                    db.SubmitChanges();
                    //MessageBox.Show("Data inserted!");

                    j++;


            }
            
                
            this.materialLabel8.Text = g.ToString();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void materialLabel3_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel7_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel8_Click(object sender, EventArgs e)
        {

        }
    }
}
